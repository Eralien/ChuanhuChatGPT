"""Summarize query."""

import logging
from typing import Any, List, Optional, cast

from llama_index.data_structs.data_structs_v2 import IndexGraph
from llama_index.data_structs.node_v2 import Node
from llama_index.indices.query.base import BaseGPTIndexQuery
from llama_index.indices.query.embedding_utils import SimilarityTracker
from llama_index.indices.query.schema import QueryBundle
from llama_index.indices.response.builder import ResponseMode
from llama_index.indices.utils import get_sorted_node_list

logger = logging.getLogger(__name__)


class GPTTreeIndexSummarizeQuery(BaseGPTIndexQuery[IndexGraph]):
    """GPT Tree Index summarize query.

    This class builds a query-specific tree from leaf nodes to return a response.
    Using this query mode means that the tree index doesn't need to be built
    when initialized, since we rebuild the tree for each query.

    .. code-block:: python

        response = index.query("<query_str>", mode="summarize")

    Args:
        text_qa_template (Optional[QuestionAnswerPrompt]): Question-Answer Prompt
            (see :ref:`Prompt-Templates`).

    """

    def __init__(
        self,
        index_struct: IndexGraph,
        num_children: int = 10,
        **kwargs: Any,
    ) -> None:
        """Initialize params."""
        if "response_mode" in kwargs:
            raise ValueError(
                "response_mode should not be specified for summarize query"
            )
        response_kwargs = kwargs.pop("response_kwargs", {})
        response_kwargs.update(num_children=num_children)
        super().__init__(
            index_struct,
            response_mode=ResponseMode.TREE_SUMMARIZE,
            response_kwargs=response_kwargs,
            **kwargs,
        )

    def _retrieve(
        self,
        query_bundle: QueryBundle,
        similarity_tracker: Optional[SimilarityTracker] = None,
    ) -> List[Node]:
        """Get nodes for response."""
        logger.info(f"> Starting query: {query_bundle.query_str}")
        index_struct = cast(IndexGraph, self._index_struct)
        all_nodes = self._docstore.get_node_dict(index_struct.all_nodes)
        sorted_node_list = get_sorted_node_list(all_nodes)
        return sorted_node_list
