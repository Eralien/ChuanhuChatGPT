"""Empty Index."""

from llama_index.indices.empty.base import GPTEmptyIndex
from llama_index.indices.empty.query import GPTEmptyIndexQuery

__all__ = [
    "GPTEmptyIndex",
    "GPTEmptyIndexQuery",
]
